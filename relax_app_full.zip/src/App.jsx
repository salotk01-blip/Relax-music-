
import { useState, useRef, useEffect } from "react";

export default function App() {
  const videoList = [
    "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"
  ];

  const [hours, setHours] = useState(1);
  const [playlist, setPlaylist] = useState([]);
  const [index, setIndex] = useState(0);
  const vidA = useRef(null);
  const vidB = useRef(null);
  const [useA, setUseA] = useState(true);

  useEffect(() => {
    let arr = [];
    let total = hours * 60 * 60; 
    let est = 600; 
    let loops = Math.ceil(total / est);
    for (let i = 0; i < loops; i++) {
      videoList.forEach(v => arr.push(v));
    }
    setPlaylist(arr);
    setIndex(0);
  }, [hours]);

  const playNext = () => {
    setIndex((i) => (i + 1) % playlist.length);
    setUseA((u) => !u);
  };

  useEffect(() => {
    if (playlist.length === 0) return;
    const currentVid = useA ? vidA.current : vidB.current;
    const nextVid = useA ? vidB.current : vidA.current;

    nextVid.src = playlist[index];
    nextVid.load();
    nextVid.style.opacity = 0;

    nextVid.oncanplay = () => {
      nextVid.play();
      fadeIn(nextVid);
      fadeOut(currentVid);
    };

  }, [index]);

  const fadeIn = (el) => {
    if (!el) return;
    el.style.transition = "opacity 1s";
    el.style.opacity = 1;
  };

  const fadeOut = (el) => {
    if (!el) return;
    el.style.transition = "opacity 1s";
    el.style.opacity = 0;
  };

  return (
    <div style={{ width: "100%", height: "100%", overflow: "hidden", position: "relative" }}>
      <video
        ref={vidA}
        autoPlay
        muted
        playsInline
        onEnded={playNext}
        style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", transition: "opacity 1s" }}
      />

      <video
        ref={vidB}
        autoPlay
        muted
        playsInline
        onEnded={playNext}
        style={{ position: "absolute", width: "100%", height: "100%", objectFit: "cover", transition: "opacity 1s" }}
      />

      <div style={{ position: "absolute", top: 20, left: 20, background: "rgba(0,0,0,0.5)", padding: 10, color: "white", borderRadius: 8 }}>
        <div>เลือกจำนวนชั่วโมง</div>
        <select value={hours} onChange={(e) => setHours(Number(e.target.value))}>
          <option value={1}>1 ชั่วโมง</option>
          <option value={2}>2 ชั่วโมง</option>
          <option value={3}>3 ชั่วโมง</option>
          <option value={5}>5 ชั่วโมง</option>
          <option value={8}>8 ชั่วโมง</option>
        </select>
      </div>
    </div>
  );
}
